#!/bin/sh
# 镜像存储位置
image_path='./docker-images/'
# 镜像集合
images=('sports-ai-coach.tar' 'sports-ai-core.tar' 'sports-api.tar' 'sports-gateway.tar' 'sports-json-mock.tar' 'sports-redis.tar')

# 载入镜像
for image in ${images[@]};do
    echo '正在载入['$image_path$image']基础镜像...'
    docker load < $image_path$image
done

echo "Docker基础镜像载入完成..."

docker-compose up -d

echo "服务启动完成"

docker-compose ps