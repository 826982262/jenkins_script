## 快速启动

> Tips：如若手动更改了`db.json`文件，则需手动重启服务重新载入

- 手动运行

```shell
$ cd src
$ npm install
# 其中本项目下的db.json为主存储文件
$ npm run start
```

- docker 运行

```shell
$ sh startup.sh
```
