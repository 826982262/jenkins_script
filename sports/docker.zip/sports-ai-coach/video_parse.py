from flask import *
import cv2
import re
import os
import numpy as np
import PoseModule as pm
import requests
import time

app = Flask(__name__)
detector = pm.poseDetector()

# 视频存放路径
attachments = '/attachments/'
# 生成图片存放路径
snapshots = '/snapshots/'


def getpath(name):
    abspath = os.path.realpath(name)
    rootpath = os.path.abspath('..')  # 获取上级路径
    return re.sub(repr(rootpath).strip("'"), '', abspath)


def url2name(url):
    return re.sub(r'\..*$', "", os.path.basename(os.path.realpath(url)))


def generaterImageSavePath(time, videoName):
    return snapshots + re.sub('\.mp4', '', videoName) + "-" + str(time) + ".jpg"


def convertStrTime2Timestamp(str):
    times = str.split(':', 2)
    return int(times[0]) * 60 + int(times[1]) * 60 + int(times[2]) * 1000


def getImage(time, videoPath, savePath):
    video = cv2.VideoCapture(videoPath)
    video.set(cv2.CAP_PROP_POS_MSEC, time * 1000)
    success, image = video.read()

    if success:
        cv2.imwrite(savePath, image)
        return True
    return False


def downloadImage(url):
    # 构造请求头
    headers = {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36'
    }
    # 发送get请求图片url
    r = requests.get(url, headers=headers)
    image_url = snapshots + str(time.time()) + '.jpg'
    # wb 以二进制打开文件并写入，文件名不存在会创建
    with open(image_url, 'wb') as f:
        f.write(r.content)  # 写入二进制内容
    return image_url


@app.route('/api/ai/coach/keypose_frame', methods=['GET', 'POST'])
def getKeyPoseFrame():
    # 获取请求图片路径
    imgPath = request.args.get(
        "image_url") if request.method == 'GET' else request.json.get('image_url')

    # 存在图片请求路径 则直接返回图片
    if imgPath and os.path.isfile(imgPath):
        return send_file(imgPath, mimetype='image/jpg')

    # 获取视频进度位置
    time = float(request.args.get("frame_position") if request.method ==
                 'GET' else request.json.get('frame_position'))
    # 视频路径
    videoPath = request.args.get(
        "video_url") if request.method == 'GET' else request.json.get('video_url')

    if time and videoPath:
        # 根据时间戳与视频路径生成照片路径
        imgPath = generaterImageSavePath(time, os.path.basename(videoPath))
        # 校验并生成响应结果
        if os.path.isfile(imgPath) or getImage(time, videoPath, imgPath):
            return jsonify(code=200, data=imgPath)
    return jsonify(code=499, message="非法参数")


@app.route('/api/ai/coach/video_info', methods=['GET', 'POST'])
def videoInfo():
    # 视频路径
    videoPath = request.args.get(
        "video_url") if request.method == 'GET' else request.json.get('video_url')
    if not os.path.isfile(videoPath):
        return jsonify(code=499, message="非法参数")
    video_name = re.sub(
        r'\..*$', "", os.path.basename(os.path.realpath(videoPath)))
    cap = cv2.VideoCapture(videoPath)
    # 宽度「float」
    width = cap.get(cv2.CAP_PROP_FRAME_WIDTH)
    # 高度「float」
    height = cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
    # 帧率
    fps = int(round(cap.get(cv2.CAP_PROP_FPS)))
    # 总帧数
    frame_counter = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    _, frame = cap.read()
    imgPath = snapshots + '{}.jpg'.format(video_name + '_thumbnail')
    cv2.imwrite(imgPath, frame)  # 存储为图像
    video_thumbnail = imgPath
    cap.release()
    # 时长，单位s
    video_play_duration = frame_counter / fps
    ret = dict(video_play_duration=video_play_duration,
               video_thumbnail=video_thumbnail,
               width=width,
               height=height)
    return ret


@app.route('/api/ai/coach/posemodel', methods=['GET', 'POST'])
def poseModel():
    video_info = request.json if "POST" == request.method else request.args
    video_url = video_info.get('video_url')
    frame_position = video_info.get('frame_position')
    image_url = video_info.get('image_url')
    if image_url and not os.path.isfile(image_url):
        if image_url.startswith('http') or image_url.startswith('https'):
            image_url = downloadImage(image_url)
        else:
            return jsonify(code=499, message="非法参数")
    image_name = url2name(image_url)
    img = cv2.imread(image_url)
    img = detector.findPose(img, False)
    lmList, pose_img = detector.findPosition(img)
    pose_img = cv2.resize(pose_img, (720, 720))
    model_image_url = snapshots + '{}.jpg'.format(image_name + '_model')
    cv2.imwrite(model_image_url, pose_img)  # 存储为图像

    if len(lmList) != 0:
        right_arm_angle = detector.findAngle(img, 12, 14, 16)
        lift_arm_angle = detector.findAngle(img, 11, 13, 15)
        right_leg_angle = detector.findAngle(img, 23, 25, 27)
        left_leg_angle = detector.findAngle(img, 24, 26, 28)

        right_arm_body_angle = detector.findAngle(img, 14, 12, 24)
        left_arm_body_angle = detector.findAngle(img, 13, 11, 23)
        right_leg_body_angle = detector.findAngle(img, 12, 24, 26)
        left_leg_body_angle = detector.findAngle(img, 11, 23, 25)

    posemodel = dict(image_url=image_url, model_image_url=model_image_url,
                     model_data=dict(right_arm=dict(right_upper_arm=right_arm_angle[0],
                                                    right_lower_arm=right_arm_angle[1],
                                                    right_arm=right_arm_angle[2]),
                                     left_arm=dict(left_upper_arm=lift_arm_angle[0],
                                                   left_lower_arm=lift_arm_angle[1],
                                                   left_arm=lift_arm_angle[2]),
                                     right_leg=dict(right_upper_leg=right_leg_angle[0],
                                                    right_lower_leg=right_leg_angle[1],
                                                    right_leg=right_leg_angle[2]),
                                     left_leg=dict(left_upper_leg=left_leg_angle[0],
                                                   left_lower_leg=left_leg_angle[1],
                                                   left_leg=left_leg_angle[2]),
                                     right_arm_body=dict(right_upper_arm=right_arm_body_angle[0],
                                                         right_body=right_arm_body_angle[1],
                                                         right_arm_body=right_arm_body_angle[2]),
                                     left_arm_body=dict(left_upper_arm=left_arm_body_angle[0],
                                                        left_body=left_arm_body_angle[1],
                                                        left_arm_body=left_arm_body_angle[2]),
                                     right_leg_body=dict(right_body=right_leg_body_angle[0],
                                                         right_upper_leg=right_leg_body_angle[1],
                                                         right_leg_body=right_leg_body_angle[2]),
                                     left_leg_body=dict(left_body=left_leg_body_angle[0],
                                                        left_upper_leg=left_leg_body_angle[1],
                                                        left_leg_body=left_leg_body_angle[2]),
                                     ))
    return posemodel


if __name__ == '__main__':
    app.run(port=5001, debug=True)
