import cv2
import matplotlib.pyplot as plt
from matplotlib.pyplot import MultipleLocator

plt.rcParams['font.sans-serif']=['SimHei'] #用来正常显示中文标签
plt.rcParams['axes.unicode_minus']=False #用来正常显示负号

y_major_locator=MultipleLocator(50)
plt.xlim(320,660)
plt.ylim(200,500)
x = [330, 375, 444, 524, 584, 652]
y = [288, 271, 260, 254, 263, 262]
plt.plot(x,y,'b-',label="1", marker='o',markersize=10,linewidth=3) # b代表blue颜色  -代表直线
x1 = [491, 479]
y1 = [216, 218]
plt.plot(x1,y1,'b-',label="1", marker='o',markersize=10,linewidth=3)
x2 = [444, 480, 464, 471]
y2 = [260, 396, 472, 477]
plt.plot(x2,y2,'b-',label="1", marker='o',markersize=10,linewidth=3)
x3 = [524, 528, 611, 587]
y3 = [254, 382, 390, 494]
plt.plot(x3,y3,'b-',label="1", marker='o',markersize=10,linewidth=3)
# plt.xticks([])  #去掉横坐标值
# plt.yticks([])  #去掉纵坐标值
plt.axis('off')
plt.savefig('./result1.jpg')#保存图片

# 创建numpy类型的ndarray对象，存放多维数组的对象
img=cv2.imread('./result1.jpg')
# <class 'numpy.ndarray'>
print(type(img))
# # 水平翻转
# flip_horizontal=cv2.flip(img,1)
# 垂直翻转
flip_vertical=cv2.flip(img,0)
# 水平加垂直翻转
# flip_hv=cv2.flip(img,-1)
# # 保存水平翻转图片
# cv2.imwrite("save_dir.jpg",flip_horizontal)
# 保存垂直翻转图片
cv2.imwrite("save_dir.jpg",flip_vertical)

# plt.title('各个区域亮度变化')
# plt.legend(loc='upper left',bbox_to_anchor=(1.0,1.0))
# plt.xticks((0,1,2,3,4,5,6,7,8),('0', '15', '30', '15', '60', '75', '90', '105', '120'))
# plt.xlabel('角度')
# plt.ylabel('亮度')
# #plt.grid(x1)
