# 导入所需要的库
import cv2
import json
# 定义保存图片函数
# image:要保存的图片名字
# address；图片地址与相片名字的前部分
# num: 相片，名字的后缀。int 类型
def save_image(image, address, num):
    address = address + str(num) + '.jpg'
    cv2.imwrite(address, image)
# 读取视频文件
videoCapture = cv2.VideoCapture("./2.mp4")
# 读帧
success, frame = videoCapture.read()
i = 0
# 设置固定帧率
timeF = 2
j = 0
while success:
    i = i + 1
    if (i % timeF == 0):
        j = j + 1
        save_image(frame, './down', j)
        print('save image:', i)
    success, frame = videoCapture.read()
    # def frames_to_timecode(framerate, frames):
    #     """
    #     视频 通过视频帧转换成时间
    #     :param framerate: 视频帧率
    #     :param frames: 当前视频帧数
    #     :return:时间（00:00:01:01）
    #     """
    #     return '{0:02d}:{1:02d}:{2:02d}:{3:02d}'.format(int(i / (3600 * 28.4)),
    #                                                     int(i / (60 * 28.4) % 60),
    #                                                     int(i / 28.4 % 60),
    #                                                     int(i % 28.4))
    # print(frames_to_timecode(25, 123))

# data1 = {"Vedio2jpg":{"test1.jpg":"00:00:01', start", "test2.jpg":"00:00:02'", "test3.jpg":"00:00:03'", "test4.jpg":"00:00:04', end", "test5.jpg":"00:00:05'"}}
# # print(data1)
# json.dump(data1,open('data1.json','w'), indent=4)
