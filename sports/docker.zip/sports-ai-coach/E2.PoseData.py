import cv2
import json
import mediapipe as mp
import time
#coding=gbk
#coding:utf-8

mpDraw = mp.solutions.drawing_utils #描出骨骼点
mpPose = mp.solutions.pose
pose = mpPose.Pose()

cap = cv2.VideoCapture('./down2.jpg')
pTime = 0
while True:
    success, img = cap.read()
    imgRGB = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    results = pose.process(imgRGB)
    #print(results.pose_landmarks)
    if results.pose_landmarks:
        mpDraw.draw_landmarks(img, results.pose_landmarks, mpPose.POSE_CONNECTIONS) #找出骨骼点并连线

        #enumerate函数用于将一个可遍历的数据对象(如列表、元组或字符串)组合为一个索引序列，同时列出数据和数据下标，一般用在 for 循环当中
        for id, lm in enumerate(results.pose_landmarks.landmark):
            h, w, c = img.shape  # shape属性可以获取矩阵的形状（例如二维数组的行列），获取的结果是一个元组
            # print(id, lm)  # id表示序列号
            cx, cy = int(lm.x * w), int(lm.y * h)
            cv2.circle(img, (cx, cy), 5, (255, 0, 0), cv2.FILLED)  #画出蓝色骨骼点并填满
            #print(id,cx,cy)

    cTime = time.time()
    fps = 1/(cTime-pTime)
    pTime = cTime

    # cv2.putText(img, str(int(fps)), (70,50), cv2.FONT_HERSHEY_PLAIN, 3, (255, 0, 0), 3)
    cv2.imshow("Image", img)
    cv2.waitKey(0)

    data2 = {"Key bone points":{"9": "495, 217","10": "482, 219","11": "533, 256","12": "446, 265","13": "593, 251","14": "383, 278","15": "657, 259",
             "16": "329, 289","23": "525, 384","24": "473, 398","25": "610, 391","26": "460, 487","27": "586, 488","28": "469, 485",}}
    json.dump(data2,open('data2.json','w'), indent=4)