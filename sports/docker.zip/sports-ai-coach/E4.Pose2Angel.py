import cv2
import numpy as np
import time
import PoseModule as pm
import pandas as pd
import json
import csv


# 读取data*.jpg图片
cap = cv2.VideoCapture('./down24.jpg')
detector = pm.poseDetector()  # 动作检测
count = 0  # 计数，做动作的次数
dir = 0
pTime = 0  # 时间设置

success, img = cap.read()

img = cv2.resize(img, (1280, 720))  # 设置图片大小
# img = cv2.imread('./data/test1.jpg')
img = detector.findPose(img, False)  #调用findPose函数
lmList = detector.findPosition(img, False)  #调用findPosition函数
# print(lmList)
if len(lmList) != 0:  # len() 返回字符串、列表、字典、元组等长度
    # 定义model，调用 pandas库
    model = pd.DataFrame()
# 左
    # 左肘
    model, _ = detector.findAngle(img, 11, 13, 15, model, True)
    # 左腋下
    model, _ = detector.findAngle(img, 23, 11, 13, model, True)
    # 左胯下
    model, _ = detector.findAngle(img, 11, 23, 25, model, True)
    # 左腿
    model, right_leg_angle = detector.findAngle(img, 23, 25, 27, model, True)
# 右
    # 右肘
    model, _ = detector.findAngle(img, 12, 14, 16, model, True)
    # 右腋下
    model, _ = detector.findAngle(img, 24, 12, 14, model, True)
    # 右胯下
    model, _ = detector.findAngle(img, 12, 24, 26, model, True)
    # 右腿
    model, left_leg_angle = detector.findAngle(img, 24, 26, 28, model, True)

    model.to_csv('./model.csv', float_format='%.0f', index=0)

    # Check for the dumbbell curls
    #lift_arm_per = np.interp(lift_arm_angle, (30, 160), (100, 0))
    #lift_arm_bar = np.interp(lift_arm_angle, (30, 160), (350, 500))
    # right_arm_per = np.interp(right_arm_angle, (50, 170), (100, 0))
    # right_arm_bar = np.interp(right_arm_angle, (50, 170), (100, 250))

    #color = (255, 0, 255)
    # 调整角度
    # if right_arm_per == 100 and lift_arm_per == 100:
    #     color = (0, 255, 0)
    #     if dir == 0:
    #         count += 0.5
    #         dir = 1
    # if right_arm_per == 0 and lift_arm_per == 0:
    #     color = (0, 255, 0)
    #     if dir == 1:
    #         count += 0.5
    #         dir = 0

    # print(left_leg_angle, right_leg_angle)
    # print(count)

cTime = time.time()
fps = 1 / (cTime - pTime)
pTime = cTime
# cv2.putText(img, str(int(fps)), (50, 100), cv2.FONT_HERSHEY_PLAIN, 5, (255, 0, 0), 5)

cv2.imshow("Image", img)
cv2.waitKey(0)

data4 = {"Key bone Angel":{"Right":{"16 14 12":"174", "14 12 24":"116","12 24 26":"73", "24 26 28":"85"},
                            "Left":{"15 13 11":"174", "13 11 23":"125","11 23 25":"72", "23 25 27":"87",}}}
json.dump(data4,open('end.json','w'), indent=4)






