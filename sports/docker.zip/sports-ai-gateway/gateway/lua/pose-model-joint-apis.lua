-- Openresty 开发API文档：https://openresty-reference.readthedocs.io/en/latest/Lua_Nginx_API/

-- 使用cjson处理json
json = require('cjson')
-- 使用table处理储存请求
table = require('table')
function table.copy(t)
    local res = {}
    for k, v in pairs(t) do
        if type(v) == 'table' then
            -- 递归解决多层table
            res[k] = table.copy(v)
        else
            res[k] = v
        end
    end
    return res
end

-- 请求方法
local request_method = ngx.req.get_method()

if request_method ~= 'POST' then
    return
end

ngx.req.read_body()
-- 请求体
local request_body = table.copy(json.decode(ngx.req.get_body_data()))
-- 动作帧图片链接
local image_url = request_body.rawFrameImageUrl
-- 模型ID
local model_id = request_body.modelId
-- 获取视频详情
local resp = ngx.location.capture('/sport/api/ai/coach/posemodel?', {args = 'image_url=' .. image_url})
-- 请求成功时追加BODY参数
if resp.status == 200 then
    local body = json.decode(resp.body)
    -- 模型ID
    request_body['key_pose_model_id'] = model_id
    -- 模型图片路径
    request_body['pose_model_image'] = body.model_image_url
    -- 模型数据
    request_body['model_data'] = json.encode(body.model_data)
end

-- 重新更新请求体
ngx.req.set_body_data(json.encode(request_body))
