-- Openresty 开发API文档：https://openresty-reference.readthedocs.io/en/latest/Lua_Nginx_API/

-- 使用cjson处理json
json = require('cjson')
-- 使用table处理储存请求
table = require('table')
function table.copy(t)
    local res = {}
    for k, v in pairs(t) do
        if type(v) == 'table' then
            -- 递归解决多层table
            res[k] = table.copy(v)
        else
            res[k] = v
        end
    end
    return res
end

function set_video_info(fileUrl, request_body)
    if fileUrl == nil then
        ngx.say('参数缺失')
        return
    end

    local resp = ngx.location.capture('/sport/api/ai/coach/video_info', {args = 'video_url=' .. fileUrl})
    -- 请求成功时追加BODY参数
    if resp.status == 200 then
        local body = json.decode(resp.body)
        request_body['vidoDuration'] = body.video_play_duration
        request_body['videoThumbnail'] = body.video_thumbnail
        request_body['videoHeight'] = body.height
        request_body['videoWidth'] = body.width
    end
end

-- 请求方法
local request_method = ngx.req.get_method()

if request_method ~= 'POST' and request_method ~= 'PUT' then
    return
end

ngx.req.read_body()
-- 请求体
local request_body = table.copy(json.decode(ngx.req.get_body_data()))
-- 视频链接
local vidoSrc = request_body.vidoSrc



if 'POST' == request_method then
    -- 视频存放路径
    local fileUrl = (vidoSrc[0] or vidoSrc[1]).fileUrl
    -- 设置视频信息
    set_video_info(fileUrl, request_body)
elseif 'PUT' == request_method then
    -- vidoSrc = json.decode(vidoSrc)
    -- 视频存放路径
    local fileUrl = (vidoSrc[0] or vidoSrc[1]).fileUrl
    -- 设置视频信息
    set_video_info(fileUrl, request_body)
end

-- 重新更新请求体
ngx.req.set_body_data(json.encode(request_body))
