cd /www/server/panel/vhost/nginx
