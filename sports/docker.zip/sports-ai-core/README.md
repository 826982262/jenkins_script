# pose-ai-core
AI健身算法
# api：
POST http://127.0.0.1:5000/Squat
# 标准数据文件:
dump.rdb
# env：
python3.7.1
flask
