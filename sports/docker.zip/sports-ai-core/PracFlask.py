from flask import *
from pathlib import Path
import time
import logging
import MockCorrect
import CorrectCore

app = Flask(__name__)

def init_logging_config():
    # 判断文件夹是否存在，不存在则创建
    Path('./logs').mkdir(parents=True, exist_ok=True)
    logging.basicConfig(filename='./logs/user_pose_data_' + time.strftime("%Y-%m-%d", time.localtime()) + '.log',
                        format='%(asctime)s - %(levelname)s -%(module)s:  %(message)s',
                        datefmt='%Y-%m-%d %H:%M:%S %p',
                        level=10)

@app.route('/api/ai/correction', methods=['GET', 'POST'])
def Dispatch():
    # 初始化日志基础配置
    init_logging_config()
    if request.method == 'POST':
        user_pose_data = request.json
        posename = user_pose_data.get('posename')
        if posename == 'test':
            return MockCorrect.test(user_pose_data, logging)
        else:
            return CorrectCore.correct(user_pose_data, logging)

if __name__ == '__main__':
    app.run(debug=True)
