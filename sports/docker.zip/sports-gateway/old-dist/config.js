if (window.ZEle === undefined) {
    window.ZEle = {};
  }
  window.ZEle.endpoint = "http://192.168.3.226:8080";
  window.ZEle.nav = "left"; // LeftNavCollaps left top both
  window.ZEle.indexPage = "";
  window.ZEle.breadcrumb = true;
  
  window.ZEle.remoteConfig = {};