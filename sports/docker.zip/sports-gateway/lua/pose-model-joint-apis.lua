-- Openresty 开发API文档：https://openresty-reference.readthedocs.io/en/latest/Lua_Nginx_API/

-- 使用cjson处理json
json = require('cjson')
-- 使用自定义table处理JSON复制
table = require('lua.table-utils')

-- 根据图片帧请求模型数据并设置进请求体
function set_pose_model_info(image_url, model_id, request_body)
    -- 获取动作模型详情
    local resp = ngx.location.capture('/sport/api/ai/coach/posemodel?', {args = 'image_url=' .. image_url})
    -- 请求成功时追加BODY参数
    if resp.status == 200 then
        local body = json.decode(resp.body)
        -- 模型ID
        request_body['key_pose_model_id'] = model_id
        -- 模型图片路径
        request_body['pose_model_image'] = body.model_image_url
        -- 模型数据
        request_body['model_data'] = json.encode(body.model_data)
    end
end

-- 目的聚合地址
local target_url = string.gsub(ngx.var.request_uri, "/api/crud/poseModelJoint/poseModelJoints/refresh", "/aggregation/poseModelJoint/refresh")
-- 接口响应结果
local resp = { body = "{\"code\": 500, \"message\": \"pose-model-joint-apis接口聚合失败\"}"}
-- 请求方法映射
local request_method_map = {
    GET = ngx.HTTP_GET,
    POST = ngx.HTTP_POST,
    DELETE = ngx.HTTP_DELETE,
    PUT = ngx.HTTP_PUT,
    PATCH = ngx.HTTP_PATCH
}

-- 请求方法
local request_method = ngx.req.get_method()

-- POST聚合
if request_method == 'POST' then
    -- 读取请求体
    ngx.req.read_body()
    -- 请求体
    local request_body = table.copy(json.decode(ngx.req.get_body_data()))
    -- 动作帧图片链接
    local image_url = request_body.rawFrameImageUrl
    -- 模型ID
    local model_id = request_body.modelId
    -- 将模型数据信息设置入请求体
    set_pose_model_info(image_url, model_id, request_body)
    -- 聚合接口
    resp = ngx.location.capture(target_url, {method = request_method_map[request_method], body = json.encode(request_body)})
elseif request_method == 'PUT' then
    resp = ngx.location.capture(target_url, {method = request_method_map[request_method], body = json.encode(request_body)})
else
    resp = ngx.location.capture(target_url, {method = request_method_map[request_method]})
end


-- 返回响应结果
ngx.say(resp.body)
