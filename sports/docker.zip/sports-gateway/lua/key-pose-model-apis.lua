-- Openresty 开发API文档：https://openresty-reference.readthedocs.io/en/latest/Lua_Nginx_API/

-- 使用cjson处理json
json = require('cjson')
-- 使用自定义table处理JSON复制
table = require('lua.table-utils')

-- 目的聚合地址
local target_url = string.gsub(ngx.var.request_uri, "/api/crud/keyPoseModel/keyPoseModels", "/aggregation/keyPoseModel")
-- 接口响应结果
local resp = { body = "{\"code\": 500, \"message\": \"key-pose-model-apis接口聚合失败\"}"}
-- 请求方法映射
local request_method_map = {
    GET = ngx.HTTP_GET,
    POST = ngx.HTTP_POST,
    DELETE = ngx.HTTP_DELETE,
    PUT = ngx.HTTP_PUT,
    PATCH = ngx.HTTP_PATCH
}
-- 请求方法
local request_method = ngx.req.get_method()

if request_method == 'POST' or request_method == 'PUT' then
    -- 读取请求体
    ngx.req.read_body()
    -- 请求体
    local request_body = table.copy(json.decode(ngx.req.get_body_data()))
    -- 视频链接
    local vidoSrc = json.decode(request_body.vidoSrc)
    -- 视频文件地址
    local fileUrl = (vidoSrc[0] or vidoSrc[1]).fileUrl

    if fileUrl == nil then
        ngx.log(ngx.STRERR, '视频文件地址缺失')
        ngx.say('{"code": 500, "message": "视频文件地址缺失"}')
        return
    end

    if request_body.frameTimePosition ~= nil then
        -- 请求获取新建动作的帧画面URL
        resp =
            ngx.location.capture(
            '/sport/api/ai/coach/keypose_frame?frame_position=' ..
            request_body.frameTimePosition .. '&video_url=' .. fileUrl
        )
        if resp.status == 200 and json.decode(resp.body).code == 200 then
            -- 设置帧URL
            request_body['rawFrameImage'] = json.decode(resp.body).data
            ngx.log(ngx.STDERR, 'body:' .. json.encode(resp))
            -- 请求获取新建动作的帧画面URL
            resp = ngx.location.capture('/sport/api/ai/coach/posemodel?image_url=' .. request_body['rawFrameImage'])
            if resp.status == 200 and json.decode(resp.body).code == 200 then
                -- 设置动作模型URL
                request_body['poseModelImage'] = json.decode(resp.body).model_image_url
            end
        else
            ngx.say('{"code": 500, "message": "请确保视频文件存在且时间位置不超出视频原有时长"}')
            return
        end
    end
    resp = ngx.location.capture(target_url, {method = request_method_map[request_method], body = json.encode(request_body)})
else
    resp = ngx.location.capture(target_url, {method = request_method_map[request_method]})
end
-- 返回响应结果
ngx.say(resp.body)
