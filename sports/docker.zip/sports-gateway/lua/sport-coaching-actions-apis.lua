-- Openresty 开发API文档：https://openresty-reference.readthedocs.io/en/latest/Lua_Nginx_API/

-- 使用cjson处理json
json = require('cjson')
-- 使用自定义table处理JSON复制
table = require('lua.table-utils')

-- 目的聚合地址
local target_url = string.gsub(ngx.var.request_uri, "/api/crud/coachingAction/coachingActions", "/aggregation/coachingAction")
-- 接口响应结果
local resp = { body = "{\"code\": 500, \"message\": \"sports-coaching-actions-apis接口聚合失败\"}"}
-- 请求方法映射
local request_method_map = {
    GET = ngx.HTTP_GET,
    POST = ngx.HTTP_POST,
    DELETE = ngx.HTTP_DELETE,
    PUT = ngx.HTTP_PUT,
    PATCH = ngx.HTTP_PATCH
}

function set_video_info(fileUrl, request_body)
    if fileUrl == nil then
        ngx.say('参数缺失')
        return
    end

    local resp = ngx.location.capture('/sport/api/ai/coach/video_info', {args = 'video_url=' .. fileUrl})
    -- 请求成功时追加BODY参数
    if resp.status == 200 then
        local body = json.decode(resp.body)
        request_body['vidoDuration'] = body.video_play_duration
        request_body['videoThumbnail'] = body.video_thumbnail
        request_body['videoHeight'] = body.height
        request_body['videoWidth'] = body.width
    end
end

-- 请求方法
local request_method = ngx.req.get_method()

if request_method == 'POST' or request_method == 'PUT' then
    -- 读取请求体
    ngx.req.read_body()
    -- 请求体
    local request_body = table.copy(json.decode(ngx.req.get_body_data()))
    -- 视频链接
    local vidoSrc = request_body.vidoSrc
    
    if type(vidoSrc) == 'string' then
        vidoSrc = json.decode(vidoSrc)
    end

    ngx.log(ngx.STDERR, type(vidoSrc))

    if 'POST' == request_method then
        -- 视频存放路径
        local fileUrl = vidoSrc[1].fileUrl
        -- 设置视频信息
        set_video_info(fileUrl, request_body)
    elseif 'PUT' == request_method then
        -- 视频存放路径
        local fileUrl = vidoSrc[1].fileUrl
        -- 设置视频信息
        set_video_info(fileUrl, request_body)
    end
    resp = ngx.location.capture(target_url, {method = request_method_map[request_method], body = json.encode(request_body)})
else
    resp = ngx.location.capture(target_url, {method = request_method_map[request_method]})
end
-- 返回响应结果
ngx.say(resp.body)
